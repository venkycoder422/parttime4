// import {v4 as uuid} from 'uuid';

// const user={
//     name:"venky",
//     id:uuid()
// }
// console.log(user);

function shopnow(){
    window.location.href="./login.html"
}