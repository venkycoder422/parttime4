const exportnavbar = ()=>{
    return `
    
    <header>
		<div id="container">
			<div class="nav-container">
				<a href="https://www.ikea.com/in/en/">
				  <img src="https://www.ikea.com/in/en/static/ikea-logo.f7d9229f806b59ec64cb.svg"/>
				</a>
				<div class="search-container">
					<img id="search_img"src="https://www.clipartmax.com/png/full/345-3454251_search-icon-html-code-search-icon-for-html.png=" alt="">
					<img id="camara_img"src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAhFBMVEX///8AAADv7+8ZGRmVlZWampqTk5P4+Pjl5eXb29v8/Pzf39/z8/Ps7OzX19e+vr6JiYl7e3ukpKQpKSnNzc1paWnExMQ+Pj5WVlaBgYGHh4ciIiJOTk4sLCw0NDRISEgRERGsrKxwcHAdHR0UFBReXl5sbGy2trZDQ0M4ODihoaGrq6tQ0xuBAAAK80lEQVR4nO1d6WKqOhDGFUUFF4qoVVFrbe37v9+t7XFmQsKSBbDefL/OoRrzwWS2TAbHsbCwsLCwsLCwsLCwsLCwsLCwsHgsuP6hawoH322aDge3d2qZxKn3YBz9rVF+N2z9pklRBMb53RA0TQtRDcEHojisiGCrNWya2i+8XWUMd17T5H7wUhnBVuulaXI3XCok2GpdmqbnOGMynVm3bwLdGRlz3DRBKqNfxgb9eiA5JYZiZXDYFQ7bsMkYb2Ame6MD72HcTbNySlbMwOjAA7K6jQ4siRDnMTc89ByHDg0PLQEX4wmzMnoDyumpuTCD6FHz/hXxBRvTp12cQ7+C4fs4fNfMiINg3pPBEWewMzODFIi/e5Sa2TwQqL3JdNlSRzXBqq8xo+V0wg7WLf5ODqaVEHScqdasqGi3dZ5fq/VaEUHHedWa17J9H2dQ/OE8vLXzJqmF9pve1P4tR3ehN0yVBjks/vk8LH4t6flxCWpTPN/GiLSG2Jl1R3kM9HIk0fcQHxrfX8yrT6R4c51V9OE4I/LfWV8u9z6UcRgnfhhGl3l3fonC0J8UfwHgDuX2C/o0RzByrvDvc2UObnhY7TctFpv96lDZEnZRt1yd+P5P89HBz2/51zyj9nqtaA8GIpPYgQ2HyPzPeOFRTIzBMaxgMYP+3DrJ/Z8yK6MUhuuyKmKxNh58Te5jJ879Xx3Dnkkk5wkuDYtQu3MfuRqGXvApxe+Gz8CksFbM8CLP74ejwQR3pQwH6hHBqzEPqUKGbmZQt/iIX2bT3nT2En9k6qCpIeNRHcOoI5p33A9SXszED/qx6KMdMyqnMoaCB7jsh1lDt8O+QOMayRhUxLC956c7KvjOiL8pexNTkWHoueMbihcIF4fF5SQu4sRVX1IlGIazj5/MdrI7X/Pv7Tw1zXP5DJyfjsK19whKMxwwtze55oyZkrZYzhEbpp6j7mIsy5DLWGbn11kfO5GXsyhhRjhKD8CgJMNJi0PWNihbrjBVccA8Vgr0NitKMhQZLHHUyjzBjXgBtn2I8X3xivaZMFnrKZZjKMxzxaLxVvQTolyBP4+3VAqTbTwX3AeX0Tg62+blGNJ0B0LgOvbo3zk16AZZ+cpzwN0MRiH3qmYozsLxlQNMRU1axfgr4Sh3rNJPkjGq6sFGKYbjdPLoF5zFYBRuasJhcbr5HJYfrhmGHvnYiRXhIe/FibBnTeeA1OJuVKNik1JKntIbEz+44nUswoxZjxOyH3OulGEpTUPKl1qMlx0I46gMdJj7RrPUioVWGtYitVlId+aYBZWvYHissn5ZLewvafFF6YiUXiBOAX0ME9F+Smf5L8Zfih7vjoo4KSYTGmBTDAVe25r9xEX8l2GS/t5+FdKHMQhXnBZKqMJZ43Ulk1HW8+bkNOVJefiXZc7Xtn2RqA366QJ/Kh8k+FfRp+WjJ/ZOp/0VstiIjKUI7rLjjCglzIQikR8V700qAt5tOt84bffztI9F1AxZhGzItc2PoyL2ORILT5aigrKRy9P8ZjEEf0BzQswWVfWtVrdIxDy20IUYHDS0CtWJZjJRE9HEmLqHU5lAf0jPEy1QTsitkt81MsMQ9R0pa6OO6Es5HeHR8JlIAxa2rbO/nAEjDNs4LbyIW8oy8yK2gfq9eFF+ciYYYlSIKpYen5EpKKSLESUbg0XpSNEIQ7TquHaIiyOXLSM5GnRiXLiWyE7OBEO0eniDiYsjq/+Im49ODIqJbFGDCYYwpTcwJHjPFeoeiG8BMjGGOEr2hhlg6Hb4Hyf5GnnNTBQXCgXcxo7krpsBhphPQQHCOaocAyFODFzDpSCZYjbAEO7uBi7hI1TL5qJZxIcIKRJJMdVn6IHvD0bBQ29GLWpFN3cBrgKYkaVchKHPED02cNhQolS3VdBkgOSj6ybnuekzRLsAl46Kk0HgbcM4FC7JBcL6DGfcXPAgovpBJTSKYIGOaqPqM4Sw7nC/gqpQvYQLnT5Qxof7la3USPoMYSqgVGAR6RwvgZgfljKqH6mBtBnC727AEoMmzdsoLgKEJov7FRfshZSC1mYIIgluMi7DouqLPKDqhIUIzryUF6HNEOIaUDTg42x0qprwiYEPA6pGqnpBmyEoPfA+DvcrervT4NeABgNPSUqZajOEbDjcakgs6h3Ug8wFpBBBOKQOH2kzBJ8N0n8Q/OidvYYFDuEXJCeXed9LQ5shKM4hd0XvpB7wAWU65K6UgTZDyGCA4uxwV5QAyrTDXUlkxtFmeP8WGin+ihJ4A69m8o0xTO5OtsddUcMEpMPjrsiMYxkWgpfJhLuiBJDJhLtSL8Pn1zTPby2e3+LzXhtsrhjy2mBbpyGv7fk975zoaaEVPcFybjp6ev4IWJDFgNyURlUoiiTknZrKYghMPqiaT6mBWMChN1A0TWWi0PwJsonqYopCymcTpcyhzQiXwPNn9XF51LUzI+fR2921EoAlc4JLpD2D3Fj/QBsh3AH1UrXvkBLVCRJFajE1d7nheYWqI5qoVBCUSZD+Y/LNDkmbUHTeseCj/koF/PEEvkmqTT4kR2NOBgCbNkTaDVSbkDLSOiqGZONqI1Vf8OsJShCpfVeu+sI40MXCMtnJGWGI1Xbiyj2ZUJisYGHlnnRbQSMMiWrAi/TsWfn6bHo4g4SBeFFacdVUQfteTgG67+Q7j1RBSwvZ0YkZMzXNZcKMEVM3jU9LOHxZGOo4gPqPHGwZMKdJJCvZE8IFa1Ubq2Snd5l4/uxphEXBaQS2BwgxCsTyVH4aIRviEyWp3gr7bIcrSB0NInejvhMluSh5KmjRFZ4K6qZ7uDRxKqgIGQ3LR1zPysU0Ip013HE05VrUvFG1pNuy3Fxvk6zTeaI+WJ14NltP17NZLDqdt2zidF4J0DNAVMg8eoSiDNZUFqmYq+W1DPanmWdNRq6nJqNx6W1T7HJisgMPPdLDKBS3/EHZFeP80JO3qrsgJhm65LT6hhUpX9gJikPMhkYjOqDqJojRLkq5HQeKOcbNdRwojQOdU/pwy7Cga0S63JaxpQdHFYY7YeV3/vCCF3F7tsUL30iw3s4f5cGYhhd+7YyHvXf2yO/uvTfkgz6XaeQjHzMhjHczYzrwZJwc9QbR5TC/zg+XaCB2xJjTpHV04JFBqouSigp0G+iiJANWoZzkncmAfb2g5nt5qui512cm2DpLdjNLNbLRfWFGJV0F0x3pYomOdGmzWV9HOinwXQXDMuvR5d2CWrsKymDCNUPZTosepD/lXn/5aqBpc53dPXf9KCtI96K+oMvLI3f3/EbI9W254bN7GbqUp+cOL11ht+HETKP2RrrsbuL32WrdX69m77G4yVbrL3TZ/cZIo1OyXnEqQdXdrjMfUS42f6Xb9Q1KHctNTqByht8c5WT11fBrDmtgKOyBnIXCfsrSqIXhN8J3MSMG71W8yKMuht+Gz+/F2S9teot7fjVvqqmP4c+v+dfVOZ3IWJxX14xWtEZ+s1aGP/DcURhdvq6969clCkduxS8ZaoBhzbAM/z4sw78Py/Dv43/JUPN066OBnK2FTHPVr2qsF7CPfHL4mvunANb4k9q0Bl9hbhy4zzqjlSvd0aT9DJiMSDVgQKvPv9VN5xnApGxd3VdDPzpuCfSxMEv9JEh+dtKD4g/+WfzL4D2vnMI+67NSJLtYl+JP/0EwmwTj53uM03S5jhsc1fZTHhGbI/+eJQsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLC4vm8R9lQZ2Ty7Ou0QAAAABJRU5ErkJggg==" alt="">
				  <button
					id="myInput"
					placeholder="What are you looking for?"
					type="text"
					class="search"
				  ></button>
				</div>
				
				<div id="image">
					<a href=""><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAeFBMVEX///8AAABISEgeHh5YWFj29vbr6+umpqZNTU3a2tqTk5MtLS1ra2teXl7y8vKCgoJ3d3cZGRnh4eG2trYlJSVERETHx8fR0dFTU1PAwMCJiYljY2O6urozMzObm5t7e3uioqIQEBBvb285OTmtra2WlpYTExM9PT3mS3w4AAAGR0lEQVR4nO2d6WKqOhRGoQgVB1SsqCitYlvf/w1vW5IwGEIIEMO53/rVqnW7BLLJtGtZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfeDuX+PFYTo4p9UlCp7g581utj7mi71uwdc3jX5/fGg9ju5Ct98Pc42H0ds9QfCHsy7BYPocQdv2NRkWTtH5y/AkVxburudaPNJ4u8/Q1RHQi9h3OtMRz3oh0b606GVsSdPthBqCRUTwVUOsHN8hX6uGWKss1IeGUEW25MoYPpKb/EV684YPVeagqzkNn3MI2UEcPifus0DbwQNV8bPA74MHIl+l9hthK3A0nTyveu8uCsz/Ai/cQEQPGezZhpu5iGQXd86YzzZsJu54HM03tF+6ZbIRGNovnY7iGAztRZc4ozDslFOebXiLVwImVLFDN+vZhqn4Re9U8VM5zrMNmy6xmCoeVeOYbmitqaLqjaXxhi69Ft8U726MN7Q8OsxyUxu3MtLQCwt4ER2PPyhlfvMMo8X8WkqG12/6k1LmN80w+LAFrBTiGGYY3EWCSkMChhkuxYIqmd8sw32ToELmN8tw1Wy4aZv5zTIkqe/EuwunabFt5jfKMMgyH/9uPKCznEm7Pr9Rht7m77E1/w/CDVGctMr8IzJkk0i1L+AyJsN8qrNN5h+VofVJFVvMyo3L0JpRRfmJlpEZWilVjGTjjM0wX1chm/lHZ8j6/LJrAEZnaHkJUXyR6/OPz9DyaeZfSmX+ERpae9rpP8nEGaNhu8w/SsM881+a44zTMM/8zX3+kRrmfeXGPv9YDeUzv4mGUrOFLu3zzxsyv1GGQfaYXA+XDTzexX1+owzpYrf7UoITW9osTotmGbImsh3CrpRZhqGa4V0UxyzDfMq3HaKPb5ihJZyYqUV0mppmmK9NaINoCbdxhpY3W06ltzbsxmjYCh+G1PDqu9rRfAwd/dh6DZ8GDGGYvQsMn4k2w+lEO1e9hjr2AVZI9Br+8/c0MBwCGEoBQwuGZYLoPV4v1vH7vo+N7fKGwfE9Tn/iXh7j9moYLfL6J29p902nsobRwmFx5+tK3B4N9ye7zKmro5xhNKnETUsftT/DL/uRjiUfZAxd3uBiUacvQ6/6RWYcOm19lDD0+au+03wRRk+GtfVrdl0Umw39usJHB6bYjyHbtPKLM3cKv+06lF9pNAxvpbibwm9T2qj2Y5i3Mek5DKwgPKdX9oiCGqHJkC1+sjfro+f+xN3mn4ROovZiyNY9rPMuVshaAPV9gU2GrHGL82vBZ45k+r4PQ+/KdbmQR9VLhjQYks9uf5eXItAZxrtbfFUnQzpTUp3eIeUm1CvMNBjSs6S6yrL8eXowDMg6ucfkR77NuWpjIzYMyanzuA2ITDG+/P3Sg+E5e376+IxLkpVq/RWxITlUk8dnyJaFbJWJhOFn4eU8VvUaRF51J7nY8FT/uS6FoythSHYa1V4Ou/pT0c0yo2ohJOFebvdWd+qwyf7l78/EVrQwyiMX7nTGJc4uB/4qpWwT8jf/LxvJMvjuSxSXf+ubrUnZzGZfdBu0cKiQLGERw28whx9N5s/PP+z/SoT91Yj3zlX4eX3b/Icd4TcPD1P9Dfsu17y3rmC24b1hyMFNuW9ewuizNGkesG9eayVqaYZE1NJQUpkZCX9V2SBehXspu8PXrT3wPq1XeIGTSu+dCTwuATkjeAmHtFHLmj/tBsn4vHstcpMS/8TtozooWRbPuXuiW1qHqZpHNDgLK0kdxN5KzHmkS395eIbcTlyHqbhIO22PrTjpN4pzYBvoasHq+U7zqEqZAxlo76l6ntIUdektUk0PmPb8B6uxSpeaOuWvlubCphzYBtqbtz9yGY+NYgxX2ZFlveIoBluh32spSzY24sT738Yr2McsTyz7DFQmYEN8ySyLG63YeFu/10axGscm2SWFYb1BC7v6hUDOrRS379K1fmLzmQ87KRdda+I27D9QIORXjxtYsLbfsxugdfN4hfdPw9ceDnm914H+58C2+s8hbupjwW14rZ4+O+XCbU242wmr12Rvlmdd9c2Dz0N+OTrL46BxvfNsfTos1/FRb23scBuny8NpPYu01+QGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMD/gv8AMclr8sCtI1EAAAAASUVORK5CYII=" alt=""></a>
					<a href="./cart/cart.html"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQjRCkLN7bqvDPYHZ4_1LlsaYeHPcDN5-7rDw&usqp=CAU" alt=""></a>
			     </div>
			  </div>   
			  <div id="lower_nav">
				<nav>
					<ul>
					  <li>
						<a href="./products.html">Products</a>
					  </li>
					  <li>
						<a href="">Rooms</a>
					  </li>
					  <li>
						<a href="https://www.ikea.com/in/en/news/">New at IKEA</a>
					  </li>
					  <li>
						<a href="https://www.ikea.com/in/en/offers/">All offers</a>
					  </li>
					</ul>
				  </nav>
				</div>
		  
		</div>
	</header>
    
    
    
    
    
    `
}

// export default exportnavbar();